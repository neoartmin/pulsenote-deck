# PulseNote Deck v3.5.0 GitHub Releases publisher
# Run in PowerShell after installing and authenticating GitHub CLI.
param(
    [Parameter(Mandatory=$true)]
    [ValidatePattern('^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$')]
    [string]$Repo
)
$ErrorActionPreference = 'Stop'
$tag = 'v3.5.0'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$assets = Join-Path $base 'Assets'
$program = Join-Path $assets 'PulseNoteDeck.exe'
$setup = Join-Path $assets 'PulseNoteDeck_Setup_v3_5_0.exe'
$updater = Join-Path $assets 'PulseNoteDeckUpdater.exe'
$manifest = Join-Path $assets 'release.json'
$notes = Join-Path $base 'RELEASE_NOTES_KO.md'
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) { throw 'GitHub CLI (gh)가 설치되지 않았습니다: https://cli.github.com/' }
& gh auth status
if ($LASTEXITCODE -ne 0) { throw '먼저 gh auth login을 실행해 주세요.' }
& gh repo view $Repo --json nameWithOwner --jq '.nameWithOwner' | Out-Null
if ($LASTEXITCODE -ne 0) { throw "저장소를 찾지 못했습니다: $Repo. github.com/new 에서 공개 저장소를 먼저 만들어 주세요." }
& gh release view $tag -R $Repo *> $null
if ($LASTEXITCODE -eq 0) { throw "이 버전 릴리스가 이미 존재합니다: $tag. 기존 릴리스를 덮어쓰지 않습니다." }
foreach($p in @($program,$setup,$updater,$notes)) { if (-not (Test-Path -LiteralPath $p)) { throw "파일 누락: $p" } }
$hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $program).Hash.ToLowerInvariant()
$info = [ordered]@{
  version = '3.5.0'
  url = "https://github.com/$Repo/releases/download/$tag/PulseNoteDeck.exe"
  sha256 = $hash
  notes = 'PulseNote Deck v3.5.0 안정화 릴리스. USB 자동 연결, 8키 기능, 트레이 상주.'
}
$json = $info | ConvertTo-Json -Depth 3
[System.IO.File]::WriteAllText($manifest,$json,[System.Text.UTF8Encoding]::new($false))
Write-Host "\nGitHub 공개 저장소: $Repo"
Write-Host "버전: $tag"
Write-Host "앱 SHA-256: $hash"
Write-Host '업로드하면 파일과 업데이트 매니페스트가 공개됩니다.'
$confirmation = Read-Host "공개 릴리스를 생성할까요? 정확히 PUBLISH 입력"
if ($confirmation -cne 'PUBLISH') { Write-Host '사용자가 취소했습니다.'; exit 1 }
& gh release create $tag $setup $program $updater $manifest (Join-Path $assets 'SHA256SUMS.txt') -R $Repo --title 'PulseNote Deck v3.5.0' --notes-file $notes --latest
if ($LASTEXITCODE -ne 0) { throw 'GitHub 릴리스 업로드 실패. 웹에서 릴리스 상태를 확인하세요.' }
Write-Host "\n배포 완료: https://github.com/$Repo/releases/tag/$tag"
Write-Host "앱 업데이트 설정 JSON: https://github.com/$Repo/releases/latest/download/release.json"
Write-Host "블로그 다운로드 링크: https://github.com/$Repo/releases/latest/download/PulseNoteDeck_Setup_v3_5_0.exe"
