# PulseNote Deck GitHub Releases 초기 설정

현재 GitHub 저장소가 연결되지 않았으므로 이 배포 도구는 **업로드 준비 완료**, **온라인 발행 전** 상태입니다.

## 첫 배포 (GitHub 웹 이용)

1. https://github.com/new 로 이동하고 `pulsenote-deck` 같은 이름의 **공개 저장소**를 생성합니다. README로 초기화하세요.
2. 저장소의 **Releases → Create a new release** 를 클릭합니다.
3. 태그 `v3.5.0`, 제목 `PulseNote Deck v3.5.0`을 입력합니다.
4. `RELEASE_NOTES_KO.md`의 내용을 릴리스 설명에 붙여넣습니다.
5. `Assets` 폴더의 EXE 3개와 `SHA256SUMS.txt`를 첨부합니다.
6. `release.json.template`을 열어 `OWNER/REPO`를 자기 GitHub 계정/저장소 이름으로 바꾼 후 **`release.json`이라는 파일명으로 저장**합니다. 그 파일도 첨부합니다.
7. **Publish release**를 누릅니다.

## CLI로 간단히 업로드

GitHub CLI 설치 및 `gh auth login` 후 PowerShell에서 배포 폴더로 이동해:

```powershell
.\Publish_GitHub_Release.ps1 -Repo "본인아이디/pulsenote-deck"
```

PowerShell 실행 정책으로 스크립트 실행이 제한된다면, 위 웹 방식으로 수동 배포할 수 있습니다. 저장소는 먼저 생성되어 있어야 합니다.

## 앱 자동 업데이트 활성화

공개 배포가 끝난 뒤 PulseNote Deck 앱의 **장치 및 설정 → HTTPS 버전 정보 JSON** 필드에 아래 형식의 실제 주소를 등록합니다.

`https://github.com/OWNER/REPO/releases/latest/download/release.json`

**OWNER/REPO는 실제 저장소 이름으로 바꿔야 합니다.** 처음에는 v3.5.0이므로 업데이트할 새 버전이 없다고 나오는 것이 정상입니다. 다음 버전을 출시하면 해당 새 릴리스에 최신 `release.json`과 `PulseNoteDeck.exe`를 함께 올려야 합니다.

블로그 공지: https://m.blog.naver.com/pulsenote524

## 주의

- 자동 업데이트 기능은 **설치 EXE가 아니라 `PulseNoteDeck.exe`**를 내려받아 교체합니다. 따라서 `release.json`의 `url`은 설치 프로그램이 아니라 실행 파일을 가리켜야 합니다.
- 현재 v3.5 업데이트 프로그램은 **100MiB 이상의 자동 업데이트 파일을 거부**합니다. 나중에 실행 파일이 100MiB를 넘으면 업데이터의 크기 제한을 수정·검증해야 합니다. GitHub Releases 자체의 대용량 배포와는 별개입니다.
- 업데이트 프로그램은 메인 EXE만 교체하므로, 업데이터나 설치 구조 자체가 달라진 경우에는 새 설치 프로그램을 통해 업데이트하세요.
- HTTPS와 SHA-256만으로 게시자 신원이 암호학적으로 검증되지는 않습니다. 향후 코드 서명과 서명된 업데이트 메타데이터를 추가하는 것을 권장합니다.
- 기존 v3.5의 정상 동작 확인 범위와 실제 릴리스 이후 설치·업데이트 동작 검증은 별개입니다.
- GitHub 사용자 계정 및 저장소를 제가 대신 만들어 두거나, 계정 연결 없이 게시했다고 주장할 수 없습니다.
