# PulseNote Deck v3.5.0 — Windows 안정화 버전

ESP32-C3 Super Mini를 이용한 8키 USB 매크로패드용 Windows 프로그램입니다.

- 물리 키 배열과 동일한 4×2 배치, 4번(상단 오른쪽) 빨간 키
- 앱 실행·단축키·웹사이트·폴더·미디어 제어·매크로·프로필
- Windows 트레이 백그라운드 실행 및 로그인 시 자동 실행
- USB COM 포트 자동 인식·재연결, 장치 연결/해제 알림
- 바탕화면 및 시작 메뉴 바로가기를 포함한 설치 프로그램
- 프로그램 설정은 기존 Windows 사용자 프로필에 유지

## 설치
`PulseNoteDeck_Setup_v3_5_0.exe`를 다운로드하여 실행하세요.
기존 설치된 PulseNote Deck은 트레이 메뉴에서 종료한 다음 설치하세요.
ESP32-C3 v2.1 펌웨어는 변경하지 않아도 됩니다.

## 다운로드 파일 안내
- `PulseNoteDeck_Setup_v3_5_0.exe` — 일반 사용자 권장 설치 프로그램
- `PulseNoteDeck.exe` — 실행 파일 (단독 실행 시 업데이터·아이콘 등 동봉 필요)
- `PulseNoteDeckUpdater.exe` — 자동 업데이트용 보조 실행 파일
- `release.json` — Windows 앱의 버전 확인용 파일
- `SHA256SUMS.txt` — 배포 파일 SHA-256 검증값

## 배포 상태와 보안
현재 코드 서명 인증서가 없으며 Windows SmartScreen 경고가 나타날 수 있습니다.
SHA-256 검증은 파일이 게시한 해시와 일치하는지 확인하지만, 악성코드가 없음을 증명하지는 않습니다.
Microsoft Defender 및 장시간 운영 검사는 사용자 환경에서 별도로 진행해야 합니다.

공식 공지: https://m.blog.naver.com/pulsenote524
